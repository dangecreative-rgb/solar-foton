/** @type {import('next').NextConfig} */
const nextConfig = {
  typescript: {
    ignoreBuildErrors: true,
  },
  images: {
    unoptimized: true,
  },
  // <CHANGE> Adicionando output standalone para melhor compatibilidade com Netlify
  output: 'export',
}

export default nextConfig
