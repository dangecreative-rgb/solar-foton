export function playCashSound() {
  const audio = new Audio("https://hebbkx1anhila5yf.public.blob.vercel-storage.com/cash-register-kaching-376867-j4mimHyNrq5nSxU8JHd6q0WHTvbHoA.mp3")
  audio.volume = 0.5 // Volume a 50% para não ser muito alto
  audio.play().catch((error) => {
    console.error("Erro ao tocar som:", error)
  })
}
