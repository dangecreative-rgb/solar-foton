# 🚀 Como fazer deploy no Netlify

## Método 1: Deploy via GitHub (Recomendado)

1. **Suba o código para o GitHub:**
   - Crie um repositório no GitHub
   - Execute no terminal:
     \`\`\`bash
     git init
     git add .
     git commit -m "Initial commit"
     git branch -M main
     git remote add origin https://github.com/seu-usuario/seu-repo.git
     git push -u origin main
     \`\`\`

2. **Conecte no Netlify:**
   - Acesse [app.netlify.com](https://app.netlify.com)
   - Clique em "Add new site" > "Import an existing project"
   - Escolha "GitHub" e autorize o acesso
   - Selecione seu repositório
   - Configure:
     - Build command: `npm run build`
     - Publish directory: `out`
   - Clique em "Deploy site"

## Método 2: Deploy via Drag & Drop

1. **Gere o build local:**
   \`\`\`bash
   npm install
   npm run build
   \`\`\`

2. **Faça upload no Netlify:**
   - Acesse [app.netlify.com/drop](https://app.netlify.com/drop)
   - Arraste a pasta `out` para a área indicada
   - Aguarde o upload e deploy automático

## Método 3: Deploy via Netlify CLI

1. **Instale a CLI do Netlify:**
   \`\`\`bash
   npm install -g netlify-cli
   \`\`\`

2. **Faça login:**
   \`\`\`bash
   netlify login
   \`\`\`

3. **Deploy:**
   \`\`\`bash
   npm run build
   netlify deploy --prod --dir=out
   \`\`\`

## ⚙️ Configurações Importantes

O projeto já está configurado com:
- ✅ `next.config.mjs` com output export
- ✅ `netlify.toml` com configurações otimizadas
- ✅ Imagens não otimizadas (necessário para export estático)

## 🔧 Personalizações Necessárias

Antes do deploy, atualize:
- **WhatsApp**: Linha 141 do arquivo `app/acesso-vip/page.tsx`
- **Domínio personalizado**: Configure no painel do Netlify após deploy

## 📱 Testando Localmente

\`\`\`bash
npm run dev
\`\`\`

Acesse: http://localhost:3000

## 🆘 Problemas Comuns

**Erro de build?**
- Verifique se todas as dependências foram instaladas: `npm install`
- Limpe o cache: `rm -rf .next node_modules && npm install`

**WhatsApp não funciona?**
- Certifique-se de usar o número no formato internacional: 5511999999999
