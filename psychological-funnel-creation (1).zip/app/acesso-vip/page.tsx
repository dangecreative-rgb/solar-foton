"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { Phone, Shield, Zap, Clock, Users, CheckCircle2, Star, Lock, AlertCircle, Sun } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { playCashSound } from "@/lib/play-cash-sound"

export default function Page3AcessoVIP() {
  const [nome, setNome] = useState("")
  const [telefone, setTelefone] = useState("")
  const [cidade, setCidade] = useState("")
  const [vagasRestantes, setVagasRestantes] = useState(17)
  const [countdown, setCountdown] = useState({ hours: 5, minutes: 43, seconds: 28 })
  const [showUrgencia, setShowUrgencia] = useState(false)

  // Countdown
  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown((prev) => {
        let { hours, minutes, seconds } = prev
        if (seconds > 0) {
          seconds--
        } else {
          seconds = 59
          if (minutes > 0) {
            minutes--
          } else {
            minutes = 59
            if (hours > 0) hours--
          }
        }
        return { hours, minutes, seconds }
      })
    }, 1000)
    return () => clearInterval(timer)
  }, [])

  // Redução de Vagas
  useEffect(() => {
    const vagasTimer = setInterval(() => {
      setVagasRestantes((prev) => {
        const novoValor = Math.max(3, prev - 1)
        if (novoValor <= 8 && !showUrgencia) {
          setShowUrgencia(true)
        }
        return novoValor
      })
    }, 15000)
    return () => clearInterval(vagasTimer)
  }, [showUrgencia])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    playCashSound()

    const mensagem = `🔥 *SOLICITAÇÃO DE VAGA VIP - INSTALAÇÃO SOLAR COM PROTOCOLO PRIORITÁRIO*

👤 *Nome:* ${nome}
📱 *Telefone:* ${telefone}
📍 *Cidade:* ${cidade}

☀️ *Mensagem Automática:*
Olá! Acabei de descobrir o "bug regulatório" da ANEEL para energia solar e quero garantir minha vaga no grupo VIP para instalar painéis solares e protocolar antes da próxima revisão tarifária.

Gostaria de receber:
✅ Análise personalizada do meu consumo
✅ Cálculo de economia com sistema solar
✅ Protocolo prioritário para travar a tarifa atual por 25 anos
✅ Desconto de até 90% na conta de luz

Agradeço o contato!`

    const numeroWhatsApp = "5511999999999" // Substitua pelo número real
    const urlWhatsApp = `https://wa.me/${numeroWhatsApp}?text=${encodeURIComponent(mensagem)}`

    window.open(urlWhatsApp, "_blank")
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-zinc-950 via-zinc-900 to-black">
      {/* Alerta de Urgência Condicional */}
      {showUrgencia && (
        <div className="fixed top-0 left-0 right-0 bg-red-600 text-white py-3 px-4 text-center font-bold z-50 animate-pulse">
          🚨 ATENÇÃO: MENOS DE 10 VAGAS RESTANTES!
        </div>
      )}

      {/* Header */}
      <div className={`bg-zinc-900 border-b border-zinc-800 py-4 px-4 ${showUrgencia ? "mt-12" : ""}`}>
        <div className="container mx-auto">
          <div className="flex items-center justify-center gap-2 mb-3">
            <Sun className="w-5 h-5 text-yellow-500" />
            <span className="text-yellow-500 font-bold text-sm">INSTALAÇÃO SOLAR VIP - ACESSO RESTRITO</span>
          </div>
          <h1 className="text-3xl md:text-4xl font-black text-white text-center">
            Grupo VIP Energia Solar - Protocolo Prioritário
          </h1>
        </div>
      </div>

      {/* Timer de Encerramento */}
      <div className="bg-gradient-to-r from-red-900 to-red-950 border-b border-red-500 py-6 px-4">
        <div className="container mx-auto max-w-4xl">
          <p className="text-center text-white font-bold mb-3">
            ⏰ INSCRIÇÕES PARA INSTALAÇÃO SOLAR COM TARIFA ATUAL ENCERRAM EM:
          </p>
          <div className="flex justify-center items-center gap-3 text-3xl md:text-5xl font-black text-white">
            <div className="bg-black/40 px-6 py-4 rounded-lg">
              {String(countdown.hours).padStart(2, "0")}
              <span className="text-xs block text-zinc-400">HORAS</span>
            </div>
            <span>:</span>
            <div className="bg-black/40 px-6 py-4 rounded-lg">
              {String(countdown.minutes).padStart(2, "0")}
              <span className="text-xs block text-zinc-400">MIN</span>
            </div>
            <span>:</span>
            <div className="bg-black/40 px-6 py-4 rounded-lg">
              {String(countdown.seconds).padStart(2, "0")}
              <span className="text-xs block text-zinc-400">SEG</span>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12 max-w-5xl">
        {/* Vagas Restantes - Destaque */}
        <div className="bg-gradient-to-r from-yellow-500 to-orange-500 text-black rounded-lg p-6 mb-12 text-center shadow-2xl shadow-yellow-500/30">
          <div className="flex items-center justify-center gap-3 mb-2">
            <AlertCircle className="w-8 h-8" />
            <p className="text-3xl md:text-4xl font-black">APENAS {vagasRestantes} VAGAS RESTANTES</p>
          </div>
          <p className="font-bold">Para instalação de energia solar com protocolo na tarifa atual HOJE</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 mb-12">
          {/* Coluna Esquerda: Benefícios */}
          <div>
            <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-8 mb-6">
              <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-3">
                <Sun className="w-7 h-7 text-yellow-500" />O Que Você Recebe no Grupo VIP Solar
              </h2>

              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0 mt-1" />
                  <div>
                    <p className="text-white font-bold">Análise Personalizada de Consumo em 24h</p>
                    <p className="text-zinc-400 text-sm">
                      Dimensionamento exato de quantos painéis solares você precisa baseado no seu consumo real
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0 mt-1" />
                  <div>
                    <p className="text-white font-bold">Projeto Completo de Energia Solar</p>
                    <p className="text-zinc-400 text-sm">
                      Planta técnica, lista de materiais e cronograma de instalação dos painéis
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0 mt-1" />
                  <div>
                    <p className="text-white font-bold">Protocolo Prioritário na ANEEL</p>
                    <p className="text-zinc-400 text-sm">
                      Garantia de protocolo ANTES da próxima revisão tarifária = economia máxima por 25 anos
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0 mt-1" />
                  <div>
                    <p className="text-white font-bold">Acompanhamento "Bug Ativo" em Tempo Real</p>
                    <p className="text-zinc-400 text-sm">
                      Notificações sobre status do protocolo e instalação dos painéis solares
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0 mt-1" />
                  <div>
                    <p className="text-white font-bold">Grupo Exclusivo WhatsApp de Instalações Solares</p>
                    <p className="text-zinc-400 text-sm">
                      Prints e provas de outros membros que já instalaram energia solar e estão economizando
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0 mt-1" />
                  <div>
                    <p className="text-white font-bold">Instalação dos Painéis com Timing Perfeito</p>
                    <p className="text-zinc-400 text-sm">
                      Coordenação estratégica para instalar e protocolar na janela regulatória ideal
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Depoimentos VIP */}
            <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-6">
              <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                <Star className="w-5 h-5 text-yellow-500 fill-yellow-500" />
                Membros VIP que instalaram energia solar com o "Bug"
              </h3>

              <div className="space-y-4">
                <div className="bg-zinc-800/50 rounded-lg p-4">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center text-white font-bold">
                      M
                    </div>
                    <div>
                      <p className="text-white font-bold text-sm">Marcelo Silva</p>
                      <p className="text-zinc-500 text-xs">São Paulo - 10 Painéis Solares</p>
                    </div>
                  </div>
                  <p className="text-zinc-300 text-sm mb-2">
                    "Entrei no grupo VIP na segunda, instalei os painéis na quarta. Conta de R$ 847 vai cair pra R$ 97.
                    É REAL."
                  </p>
                  <div className="flex items-center gap-2">
                    <span className="text-green-500 text-xs font-bold">✓ SISTEMA ATIVO</span>
                    <span className="text-zinc-600 text-xs">• há 2 dias</span>
                  </div>
                </div>

                <div className="bg-zinc-800/50 rounded-lg p-4">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-purple-600 rounded-full flex items-center justify-center text-white font-bold">
                      C
                    </div>
                    <div>
                      <p className="text-white font-bold text-sm">Carla Mendes</p>
                      <p className="text-zinc-500 text-xs">Curitiba - 8 Painéis Solares</p>
                    </div>
                  </div>
                  <p className="text-zinc-300 text-sm mb-2">
                    "No grupo tem print de todo mundo mostrando os painéis gerando energia. A galera que instalou tá
                    economizando PESADO mesmo."
                  </p>
                  <div className="flex items-center gap-2">
                    <span className="text-green-500 text-xs font-bold">✓ SISTEMA ATIVO</span>
                    <span className="text-zinc-600 text-xs">• há 4 dias</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Coluna Direita: Formulário */}
          <div>
            <div className="bg-gradient-to-br from-zinc-900 to-zinc-950 border-2 border-yellow-500 rounded-lg p-8 shadow-2xl shadow-yellow-500/20 sticky top-4">
              <div className="flex items-center justify-center gap-2 mb-6">
                <Sun className="w-6 h-6 text-yellow-500" />
                <h3 className="text-2xl font-black text-white text-center">Solicitar Instalação Solar VIP</h3>
              </div>

              <form onSubmit={handleSubmit} className="space-y-5">
                <div>
                  <label className="block text-white font-semibold mb-2 text-sm">Nome Completo</label>
                  <Input
                    type="text"
                    value={nome}
                    onChange={(e) => setNome(e.target.value)}
                    className="bg-zinc-800 border-zinc-700 text-white h-12"
                    placeholder="Seu nome completo"
                    required
                  />
                </div>

                <div>
                  <label className="block text-white font-semibold mb-2 text-sm">WhatsApp (com DDD)</label>
                  <Input
                    type="tel"
                    value={telefone}
                    onChange={(e) => setTelefone(e.target.value)}
                    className="bg-zinc-800 border-zinc-700 text-white h-12"
                    placeholder="(11) 99999-9999"
                    required
                  />
                </div>

                <div>
                  <label className="block text-white font-semibold mb-2 text-sm">Sua Cidade</label>
                  <Input
                    type="text"
                    value={cidade}
                    onChange={(e) => setCidade(e.target.value)}
                    className="bg-zinc-800 border-zinc-700 text-white h-12"
                    placeholder="Ex: São Paulo/SP"
                    required
                  />
                </div>

                <div className="bg-yellow-500/10 border border-yellow-500 rounded-lg p-4">
                  <div className="flex items-start gap-2">
                    <Phone className="w-5 h-5 text-yellow-500 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-yellow-500 font-bold text-sm mb-1">
                        Ao clicar, você será direcionado ao WhatsApp
                      </p>
                      <p className="text-zinc-400 text-xs">
                        Uma mensagem automática será enviada com sua solicitação de instalação solar VIP
                      </p>
                    </div>
                  </div>
                </div>

                <Button
                  type="submit"
                  className="w-full bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white font-black text-lg h-14 rounded-lg shadow-lg shadow-green-500/50"
                >
                  <Phone className="w-5 h-5 mr-2" />
                  SOLICITAR INSTALAÇÃO SOLAR VIA WHATSAPP
                </Button>

                <p className="text-center text-zinc-500 text-xs">
                  🔒 Seus dados são protegidos e usados apenas para contato sobre o protocolo
                </p>
              </form>

              {/* Indicadores de Confiança */}
              <div className="mt-6 pt-6 border-t border-zinc-800">
                <div className="grid grid-cols-3 gap-3 text-center">
                  <div>
                    <div className="flex items-center justify-center mb-1">
                      <Users className="w-5 h-5 text-green-500" />
                    </div>
                    <p className="text-white font-bold text-xl">847</p>
                    <p className="text-zinc-500 text-xs">Sistemas Instalados</p>
                  </div>
                  <div>
                    <div className="flex items-center justify-center mb-1">
                      <Zap className="w-5 h-5 text-yellow-500" />
                    </div>
                    <p className="text-white font-bold text-xl">R$ 2.3M</p>
                    <p className="text-zinc-500 text-xs">Economizados</p>
                  </div>
                  <div>
                    <div className="flex items-center justify-center mb-1">
                      <Clock className="w-5 h-5 text-blue-500" />
                    </div>
                    <p className="text-white font-bold text-xl">24h</p>
                    <p className="text-zinc-500 text-xs">Análise</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Aviso de Urgência */}
            <div className="mt-6 bg-red-900/30 border border-red-500 rounded-lg p-4">
              <p className="text-red-500 font-bold text-center text-sm">
                ⚠️ Após {vagasRestantes} vagas, novas instalações solares entram em LISTA DE ESPERA para protocolo na
                próxima janela (economia menor)
              </p>
            </div>
          </div>
        </div>

        {/* FAQ Rápido */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-8">
          <h3 className="text-2xl font-bold text-white mb-6 text-center">
            ❓ Perguntas Frequentes sobre Energia Solar com o "Bug"
          </h3>

          <div className="space-y-4 max-w-3xl mx-auto">
            <div className="bg-zinc-800/50 rounded-lg p-4">
              <p className="text-white font-bold mb-2">O "bug" da energia solar é legal?</p>
              <p className="text-zinc-400 text-sm">
                Sim! É 100% legal. O "bug" é apenas uma forma de explicar a vantagem de instalar painéis solares ANTES
                da próxima revisão tarifária da ANEEL. Quem protocola agora trava a tarifa de compensação atual por 25
                anos. É timing estratégico, não ilegalidade.
              </p>
            </div>

            <div className="bg-zinc-800/50 rounded-lg p-4">
              <p className="text-white font-bold mb-2">Quanto custa instalar os painéis solares?</p>
              <p className="text-zinc-400 text-sm">
                O acesso ao grupo VIP é gratuito. Você receberá uma análise personalizada sem custo. O investimento nos
                painéis solares varia conforme seu consumo (geralmente R$ 15k a R$ 30k), mas o retorno costuma se pagar
                em 3-5 anos. E a economia dura 25 anos.
              </p>
            </div>

            <div className="bg-zinc-800/50 rounded-lg p-4">
              <p className="text-white font-bold mb-2">E se eu perder a janela de hoje?</p>
              <p className="text-zinc-400 text-sm">
                Você pode instalar energia solar depois, mas vai protocolar com a tarifa FUTURA (mais cara), o que reduz
                sua economia mensal. A diferença pode ser dezenas de milhares de reais em 25 anos. É por isso que o
                timing é tão importante.
              </p>
            </div>

            <div className="bg-zinc-800/50 rounded-lg p-4">
              <p className="text-white font-bold mb-2">Os painéis solares funcionam mesmo?</p>
              <p className="text-zinc-400 text-sm">
                Sim! Energia solar é tecnologia comprovada e regulamentada pela ANEEL. Você gera sua própria energia
                durante o dia e compensa com a concessionária. A economia média é de 80-95% na conta de luz. Garantia de
                25 anos nos painéis.
              </p>
            </div>
          </div>
        </div>

        {/* Garantias */}
        <div className="mt-12 text-center">
          <div className="inline-flex items-center gap-8 text-zinc-500 text-sm">
            <div className="flex items-center gap-2">
              <Shield className="w-5 h-5" />
              <span>100% Seguro</span>
            </div>
            <div className="flex items-center gap-2">
              <Lock className="w-5 h-5" />
              <span>Dados Protegidos</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5" />
              <span>Sem Compromisso</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
