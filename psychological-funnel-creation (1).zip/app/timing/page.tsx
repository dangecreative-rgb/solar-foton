"use client"

import { useEffect, useState } from "react"
import { ArrowRight, Clock, TrendingDown, CheckCircle2, Bell, Sun, Battery } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useRouter } from "next/navigation"
import { playCashSound } from "@/lib/play-cash-sound"

export default function Page2Timing() {
  const router = useRouter()
  const [countdown, setCountdown] = useState({
    hours: 23,
    minutes: 47,
    seconds: 32,
  })
  const [consumo, setConsumo] = useState("450")
  const [economia, setEconomia] = useState(0)
  const [notifications, setNotifications] = useState<Array<{ id: number; text: string }>>([])
  const [vagasRestantes, setVagasRestantes] = useState(23)

  // Countdown Timer
  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown((prev) => {
        let { hours, minutes, seconds } = prev

        if (seconds > 0) {
          seconds--
        } else {
          seconds = 59
          if (minutes > 0) {
            minutes--
          } else {
            minutes = 59
            if (hours > 0) {
              hours--
            }
          }
        }

        return { hours, minutes, seconds }
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  // Notificações Automáticas
  useEffect(() => {
    const nomes = ["João M.", "Maria S.", "Pedro L.", "Ana R.", "Carlos P.", "Julia F.", "Roberto C.", "Fernanda M."]
    const cidades = ["São Paulo", "Rio de Janeiro", "Belo Horizonte", "Curitiba", "Porto Alegre", "Brasília"]

    const notificationInterval = setInterval(() => {
      const nome = nomes[Math.floor(Math.random() * nomes.length)]
      const cidade = cidades[Math.floor(Math.random() * cidades.length)]
      const valor = (Math.random() * 500 + 300).toFixed(0)

      const newNotification = {
        id: Date.now(),
        text: `${nome} de ${cidade} acabou de garantir economia de R$ ${valor}/mês com energia solar`,
      }

      setNotifications((prev) => [...prev.slice(-2), newNotification])

      // Reduz vagas ocasionalmente
      if (Math.random() > 0.6) {
        setVagasRestantes((prev) => Math.max(1, prev - 1))
      }
    }, 8000)

    return () => clearInterval(notificationInterval)
  }, [])

  // Cálculo de Economia
  useEffect(() => {
    const consumoNum = Number.parseInt(consumo) || 0
    const valorKwh = 0.85
    const consumoMensal = consumoNum * valorKwh
    const economiaCalculada = consumoMensal * 0.9 // 90% de economia
    setEconomia(economiaCalculada)
  }, [consumo])

  const handleNavigateWithSound = () => {
    playCashSound()
    router.push("/acesso-vip")
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-zinc-950 via-red-950 to-zinc-900">
      {/* Notificações Flutuantes */}
      <div className="fixed top-20 right-4 z-50 space-y-2 max-w-sm">
        {notifications.map((notif) => (
          <div
            key={notif.id}
            className="bg-green-500 text-white px-4 py-3 rounded-lg shadow-lg animate-in slide-in-from-right flex items-start gap-2"
          >
            <Bell className="w-4 h-4 mt-0.5 flex-shrink-0" />
            <p className="text-sm font-semibold">{notif.text}</p>
          </div>
        ))}
      </div>

      <div className="bg-red-600 text-white py-4 px-4 text-center">
        <div className="container mx-auto">
          <p className="text-sm font-bold mb-2 flex items-center justify-center gap-2">
            <Sun className="w-4 h-4" />⏰ JANELA PARA INSTALAÇÃO SOLAR COM TARIFA ATUAL ENCERRA EM:
          </p>
          <div className="flex justify-center items-center gap-4 text-2xl md:text-4xl font-black">
            <div className="bg-black/30 px-4 py-2 rounded">
              {String(countdown.hours).padStart(2, "0")}
              <span className="text-xs block">HORAS</span>
            </div>
            <span>:</span>
            <div className="bg-black/30 px-4 py-2 rounded">
              {String(countdown.minutes).padStart(2, "0")}
              <span className="text-xs block">MIN</span>
            </div>
            <span>:</span>
            <div className="bg-black/30 px-4 py-2 rounded">
              {String(countdown.seconds).padStart(2, "0")}
              <span className="text-xs block">SEG</span>
            </div>
          </div>
          <p className="text-sm mt-2 opacity-90">
            Até a próxima revisão tarifária - depois a compensação solar fica mais cara
          </p>
        </div>
      </div>

      <div className="bg-yellow-500 text-black py-3 px-4 text-center font-bold">
        🔥 APENAS {vagasRestantes} VAGAS PARA INSTALAÇÃO SOLAR COM PROTOCOLO PRIORITÁRIO HOJE
      </div>

      <div className="container mx-auto px-4 py-12 max-w-5xl">
        <div className="text-center mb-12">
          <div className="inline-block bg-red-500/20 border border-red-500 text-red-500 px-4 py-2 rounded-full text-sm font-bold mb-6 animate-pulse">
            🚨 TIMING CRÍTICO PARA ENERGIA SOLAR
          </div>
          <h1 className="text-4xl md:text-5xl font-black text-white mb-6 leading-tight">
            Instale <span className="text-yellow-500">Painéis Solares</span> e Protocole AGORA Pra Travar a Tarifa
          </h1>
          <p className="text-xl text-zinc-400">
            Calcule quanto você vai economizar com energia solar nos próximos 25 anos usando a tarifa de HOJE
          </p>
        </div>

        <div className="bg-zinc-900 border-2 border-yellow-500 rounded-lg p-8 mb-12 shadow-2xl shadow-yellow-500/20">
          <div className="flex items-center gap-3 mb-6">
            <Battery className="w-8 h-8 text-yellow-500" />
            <h2 className="text-2xl font-bold text-white">Calculadora de Economia Solar - AO VIVO</h2>
          </div>

          <div className="space-y-6">
            <div>
              <label className="block text-white font-semibold mb-3">
                Quanto você paga na conta de luz? (em kWh/mês)
              </label>
              <Input
                type="number"
                value={consumo}
                onChange={(e) => setConsumo(e.target.value)}
                className="bg-zinc-800 border-zinc-700 text-white text-2xl h-16 text-center"
                placeholder="Ex: 450"
              />
              <p className="text-zinc-500 text-sm mt-2 text-center">
                💡 Média brasileira: 300-500 kWh/mês. Casas grandes: 600-900 kWh/mês
              </p>
            </div>

            {economia > 0 && (
              <div className="space-y-4 animate-in fade-in">
                <div className="bg-gradient-to-r from-green-900/30 to-green-950/30 border border-green-500 rounded-lg p-6">
                  <p className="text-zinc-400 text-sm mb-2">Economia Mensal com Energia Solar:</p>
                  <p className="text-5xl font-black text-green-500 mb-2">R$ {economia.toFixed(2)}</p>
                  <p className="text-zinc-400 text-xs">
                    Com sistema solar instalado AGORA, travando a tarifa atual de R$ 0,85/kWh
                  </p>
                </div>

                <div className="grid md:grid-cols-3 gap-4">
                  <div className="bg-zinc-800 rounded-lg p-4 text-center">
                    <p className="text-zinc-400 text-sm mb-1">1 Ano</p>
                    <p className="text-2xl font-bold text-white">R$ {(economia * 12).toFixed(0)}</p>
                  </div>
                  <div className="bg-zinc-800 rounded-lg p-4 text-center">
                    <p className="text-zinc-400 text-sm mb-1">5 Anos</p>
                    <p className="text-2xl font-bold text-yellow-500">R$ {(economia * 60).toFixed(0)}</p>
                  </div>
                  <div className="bg-zinc-800 rounded-lg p-4 text-center border-2 border-green-500">
                    <p className="text-zinc-400 text-sm mb-1">25 Anos (Garantia dos Painéis)</p>
                    <p className="text-2xl font-bold text-green-500">R$ {(economia * 300).toFixed(0)}</p>
                  </div>
                </div>

                <div className="bg-yellow-500/10 border border-yellow-500 rounded-lg p-4">
                  <div className="flex items-start gap-3">
                    <Sun className="w-6 h-6 text-yellow-500 flex-shrink-0 mt-1" />
                    <div>
                      <p className="text-yellow-500 font-bold mb-2">Como funciona o "Bug" da Energia Solar:</p>
                      <p className="text-zinc-300 text-sm">
                        Você instala os painéis solares agora e protocola na ANEEL COM A TARIFA ATUAL (R$ 0,85/kWh). Nos
                        próximos 25 anos, quando a tarifa subir pra R$ 1,20, R$ 1,50 ou mais, você CONTINUA COMPENSANDO
                        como se ainda fosse R$ 0,85. É literalmente "congelar" o preço da luz.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-red-900/30 border border-red-500 rounded-lg p-4 text-center">
                  <p className="text-red-500 font-bold">
                    ⚠️ ATENÇÃO: Quem NÃO instalar energia solar agora vai pagar R$ {(economia * 300).toFixed(0)} A MAIS
                    nos próximos 25 anos
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-8 mb-12">
          <h3 className="text-2xl font-bold text-white mb-6 flex items-center gap-3">
            <Clock className="w-8 h-8 text-red-500" />
            Por Que Instalar Energia Solar AGORA É Crítico?
          </h3>

          <div className="space-y-4">
            <div className="flex items-start gap-4 p-4 bg-zinc-800/50 rounded-lg">
              <CheckCircle2 className="w-6 h-6 text-green-500 flex-shrink-0 mt-1" />
              <div>
                <p className="text-white font-bold mb-1">Protocolo ANTES da Revisão = Tarifa Congelada por 25 Anos</p>
                <p className="text-zinc-400 text-sm">
                  Você instala os painéis solares e trava a tarifa de compensação de HOJE (R$ 0,85/kWh) por 25 anos.
                  Todo aumento futuro da concessionária não te afeta mais.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4 p-4 bg-zinc-800/50 rounded-lg">
              <CheckCircle2 className="w-6 h-6 text-green-500 flex-shrink-0 mt-1" />
              <div>
                <p className="text-white font-bold mb-1">Sistema Solar Compensa 90% da Conta com a Tarifa de HOJE</p>
                <p className="text-zinc-400 text-sm">
                  A Resolução 999/2023 permite compensar até 90% do consumo. Mas quem protocolar depois da próxima
                  revisão vai compensar com uma tarifa MAIS ALTA = menos economia.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4 p-4 bg-red-900/30 border border-red-500 rounded-lg">
              <TrendingDown className="w-6 h-6 text-red-500 flex-shrink-0 mt-1" />
              <div>
                <p className="text-white font-bold mb-1">Perdeu a Janela = Paga Muito Mais Pela Vida Toda</p>
                <p className="text-zinc-400 text-sm">
                  Se você instalar energia solar DEPOIS da revisão tarifária, vai protocolar com a tarifa nova (mais
                  cara). Isso significa MENOS economia mensal. A diferença? Dezenas de milhares de reais em 25 anos.
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-8 mb-12">
          <div className="flex items-center justify-between mb-6">
            <h4 className="text-xl font-bold text-white">🔥 Sistemas Solares Instalados e Protocolados HOJE</h4>
            <span className="bg-red-500 text-white px-3 py-1 rounded-full text-sm font-bold animate-pulse">
              AO VIVO
            </span>
          </div>

          <div className="space-y-3 mb-6">
            <div className="flex items-center gap-3 p-3 bg-green-900/20 border border-green-500/50 rounded">
              <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-green-600 rounded-full flex items-center justify-center text-white font-bold text-lg">
                R
              </div>
              <div className="flex-1">
                <p className="text-white font-bold">Ricardo M. - Campinas/SP</p>
                <p className="text-sm text-zinc-400">
                  "Sistema de 8 painéis instalado e protocolado às 14:23h • Economia: R$ 712/mês"
                </p>
              </div>
              <CheckCircle2 className="w-5 h-5 text-green-500" />
            </div>

            <div className="flex items-center gap-3 p-3 bg-green-900/20 border border-green-500/50 rounded">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center text-white font-bold text-lg">
                L
              </div>
              <div className="flex-1">
                <p className="text-white font-bold">Luciana P. - Curitiba/PR</p>
                <p className="text-sm text-zinc-400">
                  "12 painéis solares protocolados às 15:47h • Economia: R$ 891/mês"
                </p>
              </div>
              <CheckCircle2 className="w-5 h-5 text-green-500" />
            </div>

            <div className="flex items-center gap-3 p-3 bg-green-900/20 border border-green-500/50 rounded">
              <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-purple-600 rounded-full flex items-center justify-center text-white font-bold text-lg">
                F
              </div>
              <div className="flex-1">
                <p className="text-white font-bold">Fernando S. - Porto Alegre/RS</p>
                <p className="text-sm text-zinc-400">
                  "Sistema solar completo protocolado às 16:12h • Economia: R$ 634/mês"
                </p>
              </div>
              <CheckCircle2 className="w-5 h-5 text-green-500" />
            </div>
          </div>

          <div className="bg-yellow-500/10 border border-yellow-500 rounded-lg p-4 text-center">
            <p className="text-yellow-500 font-bold">
              127 pessoas já instalaram energia solar com o "bug" HOJE • Você vai ser o 128º?
            </p>
          </div>
        </div>

        <div className="text-center">
          <Button
            onClick={handleNavigateWithSound}
            size="lg"
            className="bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white text-2xl px-16 py-10 rounded-lg font-black shadow-2xl shadow-red-500/50 animate-pulse"
          >
            GARANTIR INSTALAÇÃO SOLAR COM PROTOCOLO PRIORITÁRIO
            <ArrowRight className="w-8 h-8 ml-3" />
          </Button>
          <p className="text-zinc-500 text-sm mt-4">
            ⚡ Apenas {vagasRestantes} vagas para instalação com a tarifa atual
          </p>
          <p className="text-zinc-600 text-xs mt-2">
            Após a revisão, a economia será menor. Protocole agora e trave o melhor cenário.
          </p>
        </div>
      </div>
    </div>
  )
}
