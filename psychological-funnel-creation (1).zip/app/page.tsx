"use client"

import { useEffect, useState } from "react"
import { ArrowRight, AlertTriangle, TrendingUp, Eye, Sun } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useRouter } from "next/navigation"
import { playCashSound } from "@/lib/play-cash-sound"

export default function Page1Revelacao() {
  const router = useRouter()
  const [viewersCount, setViewersCount] = useState(47)
  const [todayInstalls, setTodayInstalls] = useState(127)

  useEffect(() => {
    const interval = setInterval(() => {
      setViewersCount((prev) => prev + Math.floor(Math.random() * 3))
      if (Math.random() > 0.7) {
        setTodayInstalls((prev) => prev + 1)
      }
    }, 5000)
    return () => clearInterval(interval)
  }, [])

  const handleNavigateWithSound = () => {
    playCashSound()
    router.push("/timing")
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-zinc-950 via-zinc-900 to-red-950">
      {/* Header com Alerta */}
      <div className="bg-red-600 text-white py-2 px-4 text-center text-sm font-bold animate-pulse">
        ⚠️ BUG DA ENERGIA SOLAR EXPOSTO • DESCONTO DE 90% NA CONTA DE LUZ ANTES DO FECHAMENTO
      </div>

      {/* Barra de Status "Ao Vivo" */}
      <div className="bg-zinc-900 border-b border-zinc-800 py-3 px-4">
        <div className="container mx-auto flex justify-between items-center text-xs text-zinc-400">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
            <span>AO VIVO</span>
          </div>
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1">
              <Eye className="w-3 h-3" />
              {viewersCount} visualizando agora
            </span>
            <span className="flex items-center gap-1">
              <Sun className="w-3 h-3 text-yellow-500" />
              {todayInstalls} sistemas solares instalados HOJE
            </span>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12 max-w-4xl">
        {/* Título Principal */}
        <div className="text-center mb-12">
          <div className="inline-block bg-yellow-500/20 border border-yellow-500 text-yellow-500 px-4 py-2 rounded-full text-sm font-bold mb-6">
            🔓 BUG REGULATÓRIO DA ENERGIA SOLAR
          </div>
          <h1 className="text-4xl md:text-6xl font-black text-white mb-6 leading-tight">
            Como <span className="text-red-500">3% dos Brasileiros</span> Descobriram o Bug da{" "}
            <span className="text-yellow-500">ANEEL</span> Para Instalar Energia Solar
          </h1>
          <p className="text-xl text-zinc-400">
            Enquanto 97% continua pagando caro na conta de luz, uma minoria esperta está instalando{" "}
            <span className="text-yellow-500 font-bold">painéis solares com uma janela regulatória temporária</span> que
            garante economia de até 90% na conta
          </p>
        </div>

        {/* Dados "Óbvios mas Ocultos" */}
        <div className="bg-zinc-900/50 border border-red-500/30 rounded-lg p-8 mb-12">
          <div className="flex items-start gap-4 mb-6">
            <AlertTriangle className="w-8 h-8 text-red-500 flex-shrink-0 mt-1" />
            <div>
              <h2 className="text-2xl font-bold text-white mb-4">O Dado Que Ninguém Te Contou</h2>
              <p className="text-zinc-300 text-lg leading-relaxed mb-4">
                A conta de luz subiu <span className="text-red-500 font-bold text-2xl">177%</span> nos últimos 15 anos.
                Todo mundo vê, reclama, mas continua pagando.
              </p>
              <p className="text-zinc-300 text-lg leading-relaxed mb-4">
                Mas aqui está o <span className="text-yellow-500 font-bold">"bug"</span>: A Resolução Normativa 999/2023
                da ANEEL criou um sistema de compensação para{" "}
                <span className="text-yellow-500 font-bold">energia solar</span> que, quando você instala NO TIMING
                CERTO (antes da próxima revisão tarifária), permite compensar até{" "}
                <span className="text-green-500 font-bold text-xl">90% da sua conta</span> pela tarifa ATUAL por 25
                anos.
              </p>
              <div className="bg-yellow-500/10 border border-yellow-500 rounded-lg p-4">
                <p className="text-white font-bold mb-2">🔑 A Chave do "Bug":</p>
                <p className="text-zinc-300 text-sm">
                  Instalar painéis solares AGORA = você trava o preço da energia de HOJE para gerar os créditos de
                  compensação. Quando a tarifa subir (e vai subir), você continua compensando na tarifa antiga. É como
                  congelar o preço da luz por 25 anos enquanto todo mundo paga cada vez mais.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Estatísticas Impactantes */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          <div className="bg-gradient-to-br from-red-900/30 to-red-950/30 border border-red-500/50 rounded-lg p-6 text-center">
            <TrendingUp className="w-12 h-12 text-red-500 mx-auto mb-3" />
            <div className="text-4xl font-black text-white mb-2">177%</div>
            <div className="text-zinc-400 text-sm">Aumento nos últimos 15 anos</div>
          </div>
          <div className="bg-gradient-to-br from-yellow-900/30 to-yellow-950/30 border border-yellow-500/50 rounded-lg p-6 text-center">
            <div className="text-4xl font-black text-yellow-500 mb-2">90%</div>
            <div className="text-zinc-400 text-sm">Economia potencial com o "bug"</div>
          </div>
          <div className="bg-gradient-to-br from-green-900/30 to-green-950/30 border border-green-500/50 rounded-lg p-6 text-center">
            <div className="text-4xl font-black text-green-500 mb-2">3%</div>
            <div className="text-zinc-400 text-sm">Dos brasileiros que sabem disso</div>
          </div>
        </div>

        {/* Revelação Progressiva */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-8 mb-12">
          <h3 className="text-2xl font-bold text-white mb-6">🧠 Tá Vendo O Que Eu Tô Vendo?</h3>

          <div className="space-y-6 text-zinc-300">
            <div className="flex gap-4">
              <div className="text-yellow-500 font-bold text-xl flex-shrink-0">1.</div>
              <div>
                <p className="font-bold text-white mb-2">A concessionária AUMENTA a tarifa todo ano</p>
                <p className="text-sm">177% em 15 anos. E você não pode fazer nada... ou pode?</p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="text-yellow-500 font-bold text-xl flex-shrink-0">2.</div>
              <div>
                <p className="font-bold text-white mb-2">
                  A ANEEL criou um sistema de compensação para ENERGIA SOLAR em 2023
                </p>
                <p className="text-sm">
                  Resolução 999/2023 - quem instala painéis solares pode compensar até 90% da conta com a energia gerada
                </p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="text-yellow-500 font-bold text-xl flex-shrink-0">3.</div>
              <div>
                <p className="font-bold text-white mb-2">
                  A compensação usa a TARIFA DO DIA DO PROTOCOLO, não a futura
                </p>
                <p className="text-sm">
                  Isso significa: protocola hoje = compensa pela tarifa de hoje pelos próximos 25 anos
                </p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="text-yellow-500 font-bold text-xl flex-shrink-0">4.</div>
              <div>
                <p className="font-bold text-white mb-2">Próxima revisão tarifária vai AUMENTAR a conta de novo</p>
                <p className="text-sm">
                  Quem não instalar energia solar ANTES da revisão vai pagar ainda mais. Para sempre.
                </p>
              </div>
            </div>
          </div>

          <div className="mt-8 p-6 bg-yellow-500/10 border border-yellow-500/50 rounded-lg">
            <p className="text-yellow-500 font-bold text-lg mb-2">⚡ O "BUG" EXPLICADO:</p>
            <p className="text-white text-base">
              Instalar painéis solares e protocolar o projeto AGORA = travar a tarifa de compensação de HOJE por 25
              anos. Quando a tarifa subir pra R$ 1,20 ou R$ 1,50 por kWh, você continua compensando como se fosse R$
              0,85. A diferença? Centenas de milhares de reais economizados enquanto 97% das pessoas ficam pagando cada
              vez mais.
            </p>
          </div>
        </div>

        {/* Prova Social Inicial */}
        <div className="bg-zinc-900/50 border border-zinc-800 rounded-lg p-6 mb-12">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-lg font-bold text-white">Quem já instalou energia solar com o "bug"</h4>
            <span className="text-sm text-zinc-500">Atualizado há 3 minutos</span>
          </div>
          <div className="space-y-3">
            <div className="flex items-start gap-3 p-3 bg-zinc-800/50 rounded">
              <div className="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center text-white font-bold">
                M
              </div>
              <div className="flex-1">
                <p className="text-sm text-white font-semibold">Marcelo R. - São Paulo</p>
                <p className="text-xs text-zinc-400">
                  "Instalei 12 painéis solares hoje às 09h. Economia de R$ 847/mês garantida por 25 anos."
                </p>
              </div>
              <span className="text-xs text-green-500">✓ ATIVO</span>
            </div>
            <div className="flex items-start gap-3 p-3 bg-zinc-800/50 rounded">
              <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold">
                C
              </div>
              <div className="flex-1">
                <p className="text-sm text-white font-semibold">Carla S. - Rio de Janeiro</p>
                <p className="text-xs text-zinc-400">
                  "Sistema solar instalado na semana passada. Conta de R$ 680 caiu pra R$ 97. O bug funciona."
                </p>
              </div>
              <span className="text-xs text-green-500">✓ ATIVO</span>
            </div>
          </div>
        </div>

        {/* CTA Principal */}
        <div className="text-center">
          <Button
            onClick={handleNavigateWithSound}
            size="lg"
            className="bg-red-600 hover:bg-red-700 text-white text-xl px-12 py-8 rounded-lg font-bold shadow-lg shadow-red-500/50 animate-pulse"
          >
            Ver Como Instalar Energia Solar Com o "Bug"
            <ArrowRight className="w-6 h-6 ml-2" />
          </Button>
          <p className="text-zinc-500 text-sm mt-4">
            ⏰ Janela para protocolar com a tarifa atual fecha em data desconhecida
          </p>
        </div>
      </div>
    </div>
  )
}
